﻿using AssetWorks.UI.Core.Utils;
using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Core;
using log4net.Layout;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.Core.Logs
{
    /// <summary>
    /// Logs class initialize Log4Net instance to genrate logs
    /// </summary>
    public class Logs
    {
        public static Logs Logger;

        /// <summary>
        /// Initializing logs instance
        /// </summary>
        private void InitializeLogger()
        {
            var patternLayout = new PatternLayout();
            patternLayout.ConversionPattern = "%date [%class] [%method] [%level]- %message%newline";
            patternLayout.ActivateOptions();

            var consoleAppender = new ConsoleAppender()
            {
                Name = "ConsoleAppender",
                Layout = patternLayout,
                Threshold = Level.All
            };

            var fileAppendar = new FileAppender()
            {
                Name = "FileAppender",
                Layout = patternLayout,
                Threshold = Level.All,
                AppendToFile = false,
                File = CreateTestResultFolder()
            };

            consoleAppender.ActivateOptions();
            fileAppendar.ActivateOptions();

            BasicConfigurator.Configure(consoleAppender, fileAppendar);
        }

        /// <summary>
        /// Genric method to be called to initilize logs
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static ILog Log<T>()
        {
            if (AppSettings.Logs)
            {
                if (Logger == null)
                    Logger = new Logs();

                Logger.InitializeLogger();

                return LogManager.GetLogger(typeof(T));
            }

            else return null;
        }

        /// <summary>
        /// Creating TestResults folder and log files
        /// </summary>
        /// <returns></returns>
        private string CreateTestResultFolder()
        {
            var solutionPath = new CommonUtils().SolutionPath();
            var parentSolutionPath = System.IO.Directory.GetParent(solutionPath).FullName + @"\TestResults";

            if (!Directory.Exists(parentSolutionPath))
                Directory.CreateDirectory(parentSolutionPath);

            parentSolutionPath = parentSolutionPath + $"\\{DateTime.Now.ToString("dd-MM-yyyy hh-mm-ss-fff")}.log";
            return parentSolutionPath;
        }
    }
}

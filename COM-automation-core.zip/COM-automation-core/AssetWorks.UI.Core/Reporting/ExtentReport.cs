﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Utils;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using Microsoft.VisualBasic;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using static System.Net.WebRequestMethods;

namespace AssetWorks.UI.Core.Reporting
{
    /// <summary>
    /// Initilizes extent report instance for reporting
    /// </summary>
    public class ExtentReport
    {
        [ThreadStatic]
        public static ExtentReports Extent;
        [ThreadStatic]
        public static ExtentTest Test;
        public ExtentReports Report;
        public static ExtentHtmlReporter HtmlReporter;
        public static String TC_Name;

        /// <summary>
        /// Configuring teh extent report
        /// </summary>
        public static void SetupExtentreport()
        {
            if (AppSettings.ExtentReport)
            {
                AppSettings.CoreLogger.Info($"Initializing Extent Report instance");
                var reportPath = new CommonUtils().GetFolderPath("Reports") + "Index.html";

                if (HtmlReporter == null)
                    HtmlReporter = new ExtentHtmlReporter(reportPath);

                HtmlReporter.Config.Theme = Theme.Dark;
                HtmlReporter.Config.DocumentTitle = "ExtentReport";
                HtmlReporter.Config.ReportName = "AssetWorksReport";

                if (Extent == null)
                    Extent = new ExtentReports();

                Extent.AttachReporter(HtmlReporter);
                AppSettings.CoreLogger.Info($"Extent report created at '{reportPath}'");
            }
        }

        /// <summary>
        /// Flush Extent Report
        /// </summary>
        public static void FlushExtentReport()
        {
            if (AppSettings.ExtentReport)
                Extent.Flush();
        }

        /// <summary>
        /// Get test case Name
        /// </summary>
        /// <param name="ContextName"></param>
        public static void CreateTest(string ContextName)
        {
            if (AppSettings.ExtentReport)
            {
                TC_Name = ContextName;
                Test = Extent.CreateTest(ContextName);
            }
        }

        /// <summary>
        /// Inserting the log in the report
        /// </summary>
        /// <param name="Driver"></param>
        public static void StoreResults(IWebDriver Driver,string TC_Name,string ModuleName,string FolderName)
        {
            if (AppSettings.ExtentReport)
            {

                DeleteScreenShotFolder(FolderName);

                bool passed = TestContext.CurrentContext.Result.Outcome.Status == NUnit.Framework.Interfaces.TestStatus.Passed;
                var exec_status = TestContext.CurrentContext.Result.Outcome.Status;
                var stacktrace = string.IsNullOrEmpty(TestContext.CurrentContext.Result.StackTrace) ? ""
                : string.Format("{0}", TestContext.CurrentContext.Result.StackTrace);
                Status logstatus = Status.Pass;
                string fileName;
                MediaEntityModelProvider mediaEntity;

                DateTime time = DateTime.Now;
                fileName = "Screenshot_" + time.ToString("h_mm_ss") + TC_Name + ".png";
                string PipelineName = $"{FolderName}_" + time.ToString("MMddyyyy");

                switch (exec_status)
                {
                    case TestStatus.Failed:
                        logstatus = Status.Fail;
                        String FailedScreenShotPath = CreateFolder(PipelineName, ModuleName, logstatus);
                        mediaEntity = CommonUtils.TakeScreenshot(Driver, FailedScreenShotPath, TC_Name);
                        Test.Log(Status.Fail, "Fail");
                        Test.Fail("ExtentReport 4 Capture: Test Failed", mediaEntity);
                        Test.Log(Status.Fail, "Traditional Snapshot below: " + Test.AddScreenCaptureFromPath("Screenshots\\" + fileName));
                        break;
                    case TestStatus.Passed:
                        logstatus = Status.Pass;
                        if (AppSettings.CaptureScreenShotForPassedTestCase)
                        {
                            String PassScreenShotPath = CreateFolder(PipelineName, ModuleName, logstatus);
                            mediaEntity = CommonUtils.TakeScreenshot(Driver, PassScreenShotPath, TC_Name);
                            Test.Log(Status.Pass, "Pass");
                            Test.Pass("ExtentReport 4 Capture: Test Passed", mediaEntity);
                            Test.Log(Status.Pass, "Traditional Snapshot below: " + Test.AddScreenCaptureFromPath("Screenshots\\" + fileName));
                        }
                        break;
                    case TestStatus.Inconclusive:
                        logstatus = Status.Warning;
                        String WarningScreenShotPath = CreateFolder(PipelineName, ModuleName, logstatus);
                        mediaEntity = CommonUtils.TakeScreenshot(Driver, WarningScreenShotPath, TC_Name);
                        Test.Log(Status.Fail, "Fail");
                        Test.Fail("ExtentReport 4 Capture: Test Failed", mediaEntity);
                        Test.Log(Status.Fail, "Traditional Snapshot below: " + Test.AddScreenCaptureFromPath("Screenshots\\" + fileName));
                        break;
                    case TestStatus.Skipped:
                        logstatus = Status.Skip;
                        break;
                    default:
                        break;
                }
                Test.Log(logstatus, "Test: " + TC_Name + " Status:" + logstatus + stacktrace);
            }
        }

        /// <summary>
        /// Creating extent report folder
        /// </summary>
        /// <param name="FolderName"></param>
        /// <returns></returns>
        private static string CreateFolder(string FolderName,string ModuleFolderName,Status ChiledFolder )
        {
            AppSettings.CoreLogger.Info("------ Creating Folder and Adding Screen Shot  -------");
            var folderPath = string.Empty;
            var solutionPath = new CommonUtils().SolutionPath();
            var parentSolutionPath = Directory.GetParent(solutionPath).FullName + $"\\{FolderName}";
            var childSolutionPath = Directory.GetParent(solutionPath).FullName + $"\\{FolderName}\\{ModuleFolderName}";
            var childfolderPass = Directory.GetParent(solutionPath).FullName + $"\\{FolderName}\\{ModuleFolderName}\\PassedTickets";
            var childfolderFailed = Directory.GetParent(solutionPath).FullName + $"\\{FolderName}\\{ModuleFolderName}\\FailedTickets";
            var childfolderWarning = Directory.GetParent(solutionPath).FullName + $"\\{FolderName}\\{ModuleFolderName}\\Warning";

            if (!Directory.Exists(parentSolutionPath))
                Directory.CreateDirectory(parentSolutionPath);
            if (!Directory.Exists(childSolutionPath))
                Directory.CreateDirectory(childSolutionPath);
            if(ChiledFolder == Status.Pass)
            {
                if (!Directory.Exists(childfolderPass))
                    Directory.CreateDirectory(childfolderPass);
                folderPath = childfolderPass;
            }
            if (ChiledFolder == Status.Fail)
            {
                if (!Directory.Exists(childfolderFailed))
                    Directory.CreateDirectory(childfolderFailed);
                folderPath = childfolderFailed;
            }
            if (ChiledFolder == Status.Warning)
            {
                if (!Directory.Exists(childfolderWarning))
                    Directory.CreateDirectory(childfolderWarning);
                folderPath = childfolderWarning;
            }
            AppSettings.CoreLogger.Info($"ScreenShot folder created at :::  '{folderPath}'");
            return folderPath;
        }

        /// <summary>
        /// Delete Screen Shot Folder
        /// </summary>
        /// <param name="FolderName"></param>
        /// <returns></returns>
        public static void DeleteScreenShotFolder(string FolderName)
        {
            AppSettings.CoreLogger.Info("------ Verify and Deleting Screen Shot Folder -------");
            var solutionPath = new CommonUtils().SolutionPath();
            var parentSolutionPath = Directory.GetParent(solutionPath).GetDirectories($"{FolderName}*");
            
            foreach (var file in parentSolutionPath)
            {
                var fileDateOfCreation = Directory.GetCreationTime(file.FullName);
                var Date = DateTime.Now.AddDays(-AppSettings.NumberOfDaysCapturedScreenShotFolderToStore);
                if (fileDateOfCreation < Date)
                {
                    if (Directory.Exists(file.FullName))
                    {
                        Directory.Delete(file.FullName, true);
                        AppSettings.CoreLogger.Info($"Deleting Screen Shot Folder :::  '{file}'");
                    }
                } 
            }  
        }
    }
}

using System;
using System.IO;
using System.Xml;
using System.Text.Json;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using AssetWorks.UI.Core.Integrations.TestRailAPI.Gurock.TestRail;

namespace AssetWorks.UI.Core.Integrations
{
    public class Integration
    {
        private APIClient client = new APIClient("https://assetworksqa.testrail.com/");
        private Dictionary<string, List<string>> referenceToIdMapping = new Dictionary<string, List<string>>();
        private List<int> testcaseIds = new List<int>();
        private int run_id;
        private int milestone_id;
        private int project_id;
        private string name;
        private string description;

        /// <summary>
        /// Initialize TestRail APIClient with settings.json.
        /// </summary>
        public void SetupAPIClient(string currentDirectory)
        {
            // read the json file for TestRail settings
            string jsonFilePath = Path.Combine(currentDirectory, "settings.json");
            JObject jsonData = JObject.Parse(File.ReadAllText(jsonFilePath));

            // initialize TestRail APIClient
            client.User = (string)jsonData["Users"];
            client.Password = (string)jsonData["Password"];

            // initialize test run settings
            milestone_id = (int)jsonData["Milestone_id"];
            project_id = (int)jsonData["Project_id"];
            name = (string)jsonData["Testrail_name"];
            description = (string)jsonData["Testrail_description"];
        }

        /// <summary>
        /// Parse mappings from QA- ID to TestRail case ID.
        /// </summary>
        public void ParseIdMapping(string currentDirectory)
        {
            try
            {
                // read the csv file for id mappings
                string csvFilePath = Path.Combine(currentDirectory, "id-mapping.csv");

                using (StreamReader reader = new StreamReader(csvFilePath))
                {
                    // skip the header line
                    reader.ReadLine();

                    // process each line in the csv
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        string[] columns = line.Split(',');

                        // Parse id and reference from column 0 and column 1
                        string id = columns[0].Trim().Substring(1);
                        string reference = columns[1].Trim();

                        // add to id lists to be included in the new test run
                        testcaseIds.Add(int.Parse(id));

                        // check if the reference already exists in the mapping
                        if (referenceToIdMapping.ContainsKey(reference))
                        {
                            referenceToIdMapping[reference].Add(id);
                        }
                        else
                        {
                            List<string> ids = new List<string> { id };
                            referenceToIdMapping.Add(reference, ids);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Parse Id mapping failed.");
            }

        }

        /// <summary>
        /// Create a new test run that includes all the cases parsed from id-mapping.csv.
        /// </summary>
        public void CreateTestRun()
        {
            try
            {
                // create a run in TestRail
                var data = new Dictionary<string, object>
                {
                    {"name", $"{name} {DateTime.Now.ToString("M/d/yyyy")}"},
                    {"milestone_id", milestone_id},
                    {"include_all", false},
                    {"case_ids", testcaseIds},
                    {"description", $"{description} {DateTime.Now.ToString("M/d/yyyy")}"}
                };

                JObject c = (JObject)client.SendPost($"add_run/{project_id}", data);
                run_id = (int)c["id"];
                Console.WriteLine("Test run created success with id: " + run_id);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Test run created failed.");
            }

        }

        /// <summary>
        /// Parse test results and update to TestRail by case.
        /// </summary>
        public void ParseResults(string trxFile)
        {
            Console.WriteLine(trxFile);

            // Load the .trx file as XML
            XDocument doc = XDocument.Load(trxFile);

            // Extract the UnitTestResult elements
            XNamespace ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
            var unitTestResults = doc.Descendants(ns + "UnitTestResult");

            foreach (var unitTestResult in unitTestResults)
            {
                // Extract the relevant data from the UnitTestResult element
                string testName = unitTestResult.Attribute("testName")?.Value;
                string outcome = unitTestResult.Attribute("outcome")?.Value;
                string errorMessage = unitTestResult.Element(ns + "Output")?.Element(ns + "ErrorInfo")?.Element(ns + "Message")?.Value;

                // Print the extracted data
                Console.WriteLine($"Test Name: {testName}");
                Console.WriteLine($"Outcome: {outcome}");
                Console.WriteLine($"Error Message: {errorMessage}");

                // extract the reference ID from testName
                // matching the regular expression (QA + digit)
                string pattern = @"QA(\d+)";
                MatchCollection matches = Regex.Matches(testName, pattern);

                foreach (Match match in matches)
                {
                    // Add hyphen to reference ID
                    string referenceId = "QA-" + match.Groups[1].Value;
                    Console.WriteLine("Match: " + referenceId);
                    // update result to testrail
                    if (referenceToIdMapping.TryGetValue(referenceId, out var case_ids))
                    {
                        foreach (var case_id in case_ids)
                        {
                            var result_data = new Dictionary<string, object>();
                            result_data.Add("status_id", outcome == "Passed" ? 1 : 5);
                            result_data.Add("comment", errorMessage);
                            try
                            {
                                JObject c_result = (JObject)client.SendPost($"add_result_for_case/{run_id}/{case_id}", result_data);
                                Console.WriteLine($"Update {testName} status success");
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"An error occurred when add result for case {case_id}: ");
                                Console.WriteLine(ex.Message);
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine($"No case_id found for testcase '{testName}");
                    }
                }
            }
        }
        /// <summary>
        /// Close the current run (mark as complete).
        /// </summary>
        public void CloseTestRun()
        {
            var close_data = new Dictionary<string, object>();
            try
            {
                JObject close_result = (JObject)client.SendPost($"close_run/{run_id}", close_data);
                Console.WriteLine($"Close test run {run_id} success");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred when close run {run_id}: ");
                Console.WriteLine(ex.Message);
            }
        }
    }
}

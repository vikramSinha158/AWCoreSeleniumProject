﻿using System;
using System.Text;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;
using Newtonsoft.Json.Linq;

namespace AssetWorks.UI.Core.Utils
{
    /// <summary>
    /// Read flat files
    /// </summary>
    public class FlatFile
    {
        string path;


        /// <summary>This method reads the content from flat file.</summary>
        /// <param name="Path">Path of the file.This path should include the name of the file.</param>
        /// <param name="Delimiter">The delimiter.</param>
        /// <returns>File content in dictionary format.</returns>
        /// <exception cref="FileNotFoundException">Either file does not exist OR path is not correct.</exception>
        /// <exception cref="FormatException">Syntax for line is not correct ,either more than one delimiters are present Or no delimiter exists.</exception>
        public Dictionary<string, string> ReadFile(string Path, char Delimiter)
        {
            Dictionary<string, string> fileContent = new Dictionary<string, string>();
            if (File.Exists(Path))
            {
                if (GetExtension(Path))
                {
                    using TextFieldParser parser = new TextFieldParser(Path);
                    {
                        parser.TextFieldType = FieldType.Delimited;
                    }
                    parser.SetDelimiters(Delimiter.ToString().Trim());
                    string line = string.Empty;
                    long EmptyFileSize = 0;
                    if (!FileLength(Path).Equals(EmptyFileSize))
                    {
                        while (!parser.EndOfData)
                        {
                            line = parser.ReadLine();
                            if (line != null)
                            {
                                int count = line.ToCharArray().Count(c => c == Delimiter);
                                if (count > 1 || count == 0)
                                {
                                    throw new FormatException("Syntax for line is not correct ,either more than one " + Delimiter.ToString() + " are present Or no delimiter exists.");
                                }
                                else
                                {
                                    string[] fileLineData = line.Split(Delimiter, StringSplitOptions.RemoveEmptyEntries);
                                    fileContent.Add(fileLineData[0].Trim(), fileLineData[1].Trim());
                                }
                            }
                        }
                    }
                    else
                        throw new NullReferenceException("Nothing to read. File is blank.");
                }
            }
            else
            {
                throw new FileNotFoundException("Either file does not exist OR path is not correct.");
            }
            return fileContent;
        }


        /// <summary>This method retrieves the solution path.</summary>
        /// <returns> Solution path.</returns>
        public string GetSolutionPath()
        {
            string SolutionPath = System.AppDomain.CurrentDomain.BaseDirectory;
            string[] splitpath = SolutionPath.Split(new[] { "bin" }, StringSplitOptions.None);
            string path = Directory.GetParent(splitpath[0]).FullName;
            AppSettings.CoreLogger.Info($"Getting Solution path as '{path}'");
            return path;
        }

        /// <summary>This method gets the path of the file.</summary>
        /// <param name="Path">The file path.</param>
        /// <returns>Path of the file</returns>
        private string GetPath(string Path)
        {
            Path = Path == "" ? GetSolutionPath() : Path;
            this.path = Path;
            AppSettings.CoreLogger.Info($"Getting path as '{path}'");
            return this.path;
        }

        /// <summary>This method reads Json file.</summary>
        /// <param name="Path">The file path.</param>
        /// <returns>The content of file in dictionary format.</returns>
        /// <exception cref="FileNotFoundException">Either file does not exist OR file path is not valid.</exception>
        public Dictionary<string, string> JsonFileRead(string Path)
        {
            if (File.Exists(Path))
            {
                using StreamReader r = new StreamReader(Path);
                string jsonString = r.ReadToEnd();
                JObject jsonObj = JObject.Parse(jsonString);
                Dictionary<string, string> dictObj = jsonObj.ToObject<Dictionary<string, string>>();
                return dictObj;
            }
            else
                throw new FileNotFoundException("Either file does not exist OR file path is not valid.");
        }

        /// <summary>This method get the length of the file.</summary>
        /// <param name="Path">The ile path.</param>
        /// <returns>File length in long.</returns>
        private long FileLength(string Path)
        {
            FileInfo fi = new FileInfo(Path);
            long FileSize = fi.Length;
            AppSettings.CoreLogger.Info($"Getting file size as '{FileSize}'");
            return FileSize;
        }

        /// <summary>This method gets the extension of file.</summary>
        /// <param name="Path">The  file path.</param>
        /// <returns>true if the file extension is of supported format.Else will throw format exception.</returns>
        /// <exception cref="FormatException">File format is not supported." + "Supported file formats are : .text,.config,.csv and .properties</exception>
        private bool GetExtension(string Path)
        {
            string FileExtension = System.IO.Path.GetExtension(Path).ToLower().Trim();
            if (FileExtension.Contains(".txt") || FileExtension.Contains(".config") || FileExtension.Contains(".properties") || FileExtension.Contains(".csv"))
            {
                return true;
            }
            else
                throw new FormatException("File format is not supported." + "Supported file formats are : .text,.config,.csv and .properties"); ;
        }
    }
}

﻿using System;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace AssetWorks.UI.Core.Utils
{

    /// <summary>
    /// Read and return test data from json
    /// </summary>
    public class TestDataReader
    {  
        public string TestConfig=string.Empty;     

        /// <summary> This load test data from Json file. </summary>
        /// <param name="Filename">The filename<see cref="string"/>.</param>
        /// <param name="VerificationKey">The verificationKey<see cref="string"/>.</param>
        /// <exception cref="Exception"></exception>
        public  void LoadTestDataFromJson(string Filename, string VerificationKey)
        {
            CommonUtils commonUtils = new CommonUtils();
            var requestData = JObject.Parse(
                (File.ReadAllText(commonUtils.GetFolderPath("TestData") + Filename))
                ).GetValue(VerificationKey).ToObject<JObject>();

            if (requestData == null)
                throw new Exception("Test data not available for " + Filename + " : " + VerificationKey);
            AppSettings.CoreLogger.Info($"Setting test data for '{Filename}' : '{VerificationKey}'");
            TestConfig = JsonConvert.SerializeObject(requestData);
            AppSettings.CoreLogger.Info($"Test data loaded '{TestConfig}'");
        }

        /// <summary> This get test data value by test data key. </summary>
        /// <param name="Key">The key <see cref="string"/>.</param>
        /// <returns> test data value <see cref="string"/>.</returns>
        /// <exception cref="Exception"></exception>
        public string GetTestdataValueByDataKey(string Key)
        {
            string value = null;
            var dataset = JsonConvert.DeserializeObject<Dictionary<string, string>>(TestConfig);
            if (dataset.ContainsKey(Key))
            {
                foreach (KeyValuePair<string, string> item in dataset)
                {
                    if (item.Key == Key)
                    {
                        value = item.Value;
                        break;
                    }
                }
            }
            else
                throw new Exception("Key : " + Key + " not found in test data.");

            if (value == null)
                throw new Exception("Test data not available for " + Key);

            AppSettings.CoreLogger.Info($"Test data for '{Key}' : '{value}'");
            return value;
        }

        /// <summary> This get test data object by test data key. </summary>
        /// <param name="Key">The key <see cref="string"/>.</param>
        /// <returns> dynamic test data value <see cref="Object"/>.</returns>
        /// <exception cref="Exception"></exception>
        public  dynamic GetTestdataObjectByDataKey(string Key)
        {
            dynamic value = null;
            var dataobject = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(TestConfig);
            if (dataobject.ContainsKey(Key))
            {
                foreach (KeyValuePair<string, dynamic> item in dataobject)
                {
                    if (item.Key == Key)
                    {
                        value = item.Value;
                        break;
                    }
                }
            }
            else
                throw new Exception("Key : " + Key + " not found in test data.");

            if (value == null)
                throw new Exception("Test data not available for " + Key);

            AppSettings.CoreLogger.Info($"Test data for '{Key}' : '{value.ToString()}'");
            return value;
        }

        /// <summary> This get test data value from object using data key. </summary>
        /// <param name="Key">The key <see cref="string"/>.</param>
        /// <param name="RequestData">The request data <see cref="JObject"/>.</param>
        /// <returns> test data value <see cref="string"/>.</returns>
        /// <exception cref="Exception"></exception>
        public static string GetTestdataFromObjectBykey(string Key, JObject RequestData)
        {
            string value = null;
            if (RequestData != null)
            {
                var testData = JsonConvert.SerializeObject(RequestData);
                var dataset = JsonConvert.DeserializeObject<Dictionary<string, string>>(testData);
                if (dataset.ContainsKey(Key))
                {
                    foreach (KeyValuePair<string, string> item in dataset)
                    {
                        if (item.Key == Key)
                        {
                            value = item.Value;
                            break;
                        }
                    }
                }
                else
                    throw new Exception("Key : " + Key + " not found in test data.");
            }
            else
                throw new Exception("request data must not be mull.");

            if (value == null)
                throw new Exception("Test data not available for " + Key);

            AppSettings.CoreLogger.Info($"Test data for '{Key}' : '{value}'");
            return value;
        }

    }
}

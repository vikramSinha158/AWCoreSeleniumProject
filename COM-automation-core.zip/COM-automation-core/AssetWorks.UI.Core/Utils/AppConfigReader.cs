﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.Core.Utils
{
    /// <summary>
    /// Get data from AppSetting file
    /// </summary>
    internal class AppConfigReader
    {
        readonly CommonUtils CommonUtility = new CommonUtils();

        public static string? AppSettingPath { get; set; }
        private Dictionary<string, string> Config => CommonUtility.LoadFiles(AppSettingPath, CommonUtility.UserDelimeter);

        public void LoadSettings()
        {
            AppSettings.HeadlessFlag = bool.Parse(Config["HeadlessFlag"].Trim());
            AppSettings.RemoteFlag = bool.Parse(Config["RemoteFlag"].Trim());
            AppSettings.PlatformName = Config["RemotePlatformName"].Trim();
            AppSettings.Platform = Config["RemoteCapabilityPlatformName"].Trim();
            AppSettings.WaitTime = int.Parse(Config["RemoteDriverWaitTime"].Trim());
            AppSettings.HubUrl = Config["HubUrl"].Trim();
            AppSettings.Windows10 = bool.Parse(Config["Window10Flag"].Trim());
            AppSettings.ExtentReport = bool.Parse(Config["ExtentReport"]);
            AppSettings.CaptureScreenShotForPassedTestCase = bool.Parse(Config["CaptureScreenShotForPassedTestCase"]);
            AppSettings.NumberOfDaysCapturedScreenShotFolderToStore = int.Parse(Config["NumberOfDaysCapturedScreenShotFolderToStore"].Trim());
            AppSettings.TestRailReport = bool.Parse(Config["TestRailReport"]);
            AppSettings.ApiBaseUrl = Config["ApiBaseUrl"].Trim();
            AppSettings.ApiUsername = Config["ApiUsername"].Trim();
            AppSettings.ApiPassword = Config["ApiPassword"].Trim();
            AppSettings.ApiEndPoint = Config["ApiEndPoint"].Trim();
            AppSettings.ApiProjectId = int.Parse(Config["ApiProjectId"].Trim());
            AppSettings.ApiMilestoneId = int.Parse(Config["ApiMilestoneId"].Trim());
            AppSettings.Logs = bool.Parse(Config["Logs"].Trim());
        }
    }
}

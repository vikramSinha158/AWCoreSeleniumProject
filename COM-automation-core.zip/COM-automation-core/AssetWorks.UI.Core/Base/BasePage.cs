﻿using AssetWorks.UI.Core.Utils;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.Core.Base
{
    /// <summary>
    /// Base page class
    /// </summary>
    public class BasePage : Base
    {
        public BasePage(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Wait Until Displayed using Defaul tWait
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="WaitTime"></param>
        /// <returns></returns>
        public static bool WaitUntilDisplayed(IWebElement Element, string elementName, int WaitTime = 30)
        {
            bool Flag = false;

            DefaultWait<IWebElement> Wait = null;
            try
            {
                Wait = new DefaultWait<IWebElement>(Element);
                Wait.Timeout = GetWaitTimeInSeconds(WaitTime);
                Wait.PollingInterval = TimeSpan.FromMilliseconds(250);
                Flag = Wait.Until(FnCheckDisplayed);
            }

            catch
            {
                
            }

            return Flag;
        }

        /// <summary>
        /// Get Wait Time In Seconds
        /// </summary>
        /// <param name="WaitTime"></param>
        /// <returns></returns>
        private static TimeSpan GetWaitTimeInSeconds(int WaitTime)
        {
            return TimeSpan.FromSeconds(WaitTime);
        }

        /// <summary>
        /// Func to check Display
        /// </summary>
        static Func<IWebElement, bool> FnCheckDisplayed = new Func<IWebElement, bool>((IWebElement ele) =>
        {
            if (ele.Displayed && ele.Enabled)
            {
                return true;
            }
            return false;
        });

        /// <summary>
        /// Func to check Enabled
        /// </summary>
        static Func<IWebElement, bool> FnCheckEnabled = new Func<IWebElement, bool>((IWebElement ele) =>
        {
            if (ele.Displayed)
            {
                return true;
            }
            return false;
        });

        /// <summary>
        /// Wait Until Visible using Locator 
        /// </summary>
        /// <param name="Locator"></param>
        /// <param name="LocatorType"></param>
        /// <param name="Timeout"></param>
        public void WaitUntilVisible(string Locator, string LocatorType, string elementName, int Timeout = 30)
        {
            AppSettings.CoreLogger.Info($"Waiting for '{elementName}' to display");

            try
            {
                WaitForAllElementsVisibility(GetLocator(LocatorType, Locator), Timeout);
            }
            catch (Exception ex)
            {
                Assert.Fail("Element is not visible: " + elementName + ";  " + ex.Message);
            }
        }

        /// <summary>
        /// Wait For All Element sVisibility
        /// </summary>
        /// <param name="ByLocator"></param>
        /// <param name="Timeout"></param>
        public void WaitForAllElementsVisibility(By ByLocator, int Timeout)
        {
            WaitForCondition(ExpectedConditions.VisibilityOfAllElementsLocatedBy(ByLocator), Timeout);
        }

        /// <summary>
        /// Wait For Condition
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Condition"></param>
        /// <param name="Timeout"></param>
        /// <returns></returns>
        private T WaitForCondition<T>(Func<IWebDriver, T> Condition, int Timeout = 60)
        {
            var Wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(Timeout));
            Wait.PollingInterval = TimeSpan.FromMilliseconds(250); ;
            return Wait.Until(Condition);
        }

        /// <summary>
        /// Get Locator
        /// </summary>
        /// <param name="LocatorType"></param>
        /// <param name="LocatorValue"></param>
        /// <returns></returns>
        private By GetLocator(string LocatorType, string LocatorValue)
        {
            By by = null;

            if (string.IsNullOrEmpty(LocatorType) || string.IsNullOrEmpty(LocatorValue))
            {
                Assert.Fail("Locator detail or type is empty");
            }

            switch (LocatorType.ToUpper())
            {
                case "ID":
                    by = By.Id(LocatorValue);
                    break;
                case "XPATH":
                    by = By.XPath(LocatorValue);
                    break;
                case "NAME":
                    by = By.Name(LocatorValue);
                    break;
                case "CSS":
                    by = By.CssSelector(LocatorValue);
                    break;
                case "CLASSNAME":
                    by = By.ClassName(LocatorValue);
                    break;
                case "LINKTEXT":
                    by = By.LinkText(LocatorValue);
                    break;
                case "PARTIALLINKTEXT":
                    by = By.PartialLinkText(LocatorValue);
                    break;
                case "TAGNAME":
                    by = By.TagName(LocatorValue);
                    break;

            }

            if (by == null)
            {
                Assert.Fail("Invalid Locator Type");
            }

            return by;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.Core.Base
{
    /// <summary>
    /// All browsers type enum
    /// </summary>
    public enum BrowserType
    {
        CHROME,
        IE,
        EDGE
    }
}

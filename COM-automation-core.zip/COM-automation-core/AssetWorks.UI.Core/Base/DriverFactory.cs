﻿using AssetWorks.UI.Core.Utils;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AssetWorks.UI.Core.Base
{
    /// <summary>
    /// Driver factory class to initialize browser driver
    /// </summary>
    public class DriverFactory
    {
        private IWebDriver? _driver = null;

        /// <summary>This property gets the driver and is read-only property.value for this property is being set internally.</summary>
        /// <value>The remoteWebDriver Instance.</value>
        public IWebDriver Driver
        {
            get
            {
                return _driver;
            }
            private set
            {
                _driver = value;
            }
        }

        /// <summary>This method initialize driver based upon browserName being passed on as parameter by user.</summary>
        /// <param name="BrowserName">Name of the browser where you want to execute the test.</param>
        /// <returns>Webdriver instance.</returns>
        public IWebDriver? InitDriver(string BrowserName)
        {
            ResetDriver();
            string browser = BrowserName.ToUpper();
            if (_driver == null)
            {
                if (AppSettings.RemoteFlag)
                    AppSettings.CoreLogger.Info($"Initiating remote browser instance for '{BrowserName}'");
                else
                    AppSettings.CoreLogger.Info($"Initiating browser instance for '{BrowserName}'");

                switch (browser)
                {
                    case nameof(BrowserType.CHROME):
                        InitChrome(AppSettings.RemoteFlag);
                        break;
                    case nameof(BrowserType.EDGE):
                        InitEdge(AppSettings.RemoteFlag);
                        break;
                    case nameof(BrowserType.IE):
                        InitIE(AppSettings.RemoteFlag);
                        break;
                }
            }
            return _driver;
        }

        /// <summary>This method initializes Chrome browser locally and with  remote capabilities.</summary>
        private void InitChrome(bool Remote)
        {
            if (!Remote)
            {
                _driver = new ChromeDriver(ChromeDriverService.CreateDefaultService(), CheckHeadlessChrome(), TimeSpan.FromSeconds(AppSettings.WaitTime));
            }
            else
            {
                ChromeOptions option = CheckHeadlessChrome();
                _driver = new RemoteWebDriver(new Uri(AppSettings.HubUrl), SetRemoteChromeCapabilities(option).ToCapabilities(), TimeSpan.FromSeconds(AppSettings.WaitTime));
            }
        }

        /// <summary>This method initializes Edge browser locally and with remote capabilities.</summary>
        private void InitEdge(bool Remote)
        {
            if (!Remote)
            {
                _driver = new EdgeDriver(EdgeDriverService.CreateDefaultService(), CheckHeadlessEdge(), TimeSpan.FromSeconds(AppSettings.WaitTime));
            }
            else
            {
                EdgeOptions option = CheckHeadlessEdge();
                _driver = new RemoteWebDriver(new Uri(AppSettings.HubUrl), SetRemoteEdgeCapabilities(option).ToCapabilities(), TimeSpan.FromSeconds(AppSettings.WaitTime));
            }
        }

        /// <summary>This method initializes IE browser locally with no remote capabilities.</summary>
        private void InitIE(bool remote)
        {
            if (!remote)
            {
                _driver = new InternetExplorerDriver(InternetExplorerDriverService.CreateDefaultService(), CheckHeadlessIE(), TimeSpan.FromSeconds(AppSettings.WaitTime));
            }
            else
            {
                InternetExplorerOptions option = CheckHeadlessIE();
                _driver = new RemoteWebDriver(new Uri(AppSettings.HubUrl), SetRemoteIECapabilities(option).ToCapabilities(), TimeSpan.FromSeconds(AppSettings.WaitTime));
            }
        }

        /// <summary>This method sets the remote chrome capabilities.</summary>
        /// <param name="option">The Chrome options.</param>
        /// <returns> ChromeOptions.</returns>
        private ChromeOptions SetRemoteChromeCapabilities(ChromeOptions option)
        {
            //to do
            return option;
        }


        /// <summary>This method checks for headless flag in settings and apply chrome options accordingly.</summary>
        /// <returns>ChromeOption.</returns>
        private ChromeOptions CheckHeadlessChrome()
        {
            ChromeOptions option = new ChromeOptions();
            if (AppSettings.HeadlessFlag)
                option.AddArgument("--headless");
            option.AddArgument("--safebrowsing-disable-download-protection");
            option.AddArgument("safebrowsing-disable-extension-blacklist");
            option.AddUserProfilePreference("safebrowsing.enabled", true);
            return option;
        }

        /// <summary>This method sets the remote Edge capabilities.</summary>
        /// <param name="option">The Chrome options.</param>
        /// <returns> ChromeOptions.</returns>
        private EdgeOptions SetRemoteEdgeCapabilities(EdgeOptions option)
        {
            option.PlatformName = AppSettings.PlatformName;
            option.AddAdditionalEdgeOption("platform", AppSettings.Platform);
            option.AddArgument("no-sandbox");
            return option;
        }

        /// <summary>This method checks for headless flag in settings and apply Edge options accordingly.</summary>
        /// <returns>ChromeOption.</returns>
        private EdgeOptions CheckHeadlessEdge()
        {
            EdgeOptions option = new EdgeOptions();
            if (AppSettings.HeadlessFlag)
                option.AddArgument("--headless");
            return option;
        }

        /// <summary>This method sets the remote IE capabilities.</summary>
        /// <param name="option">The Chrome options.</param>
        /// <returns> ChromeOptions.</returns>
        private InternetExplorerOptions SetRemoteIECapabilities(InternetExplorerOptions option)
        {
            option.PlatformName = AppSettings.PlatformName;
            option.AddAdditionalInternetExplorerOption("platform", AppSettings.Platform);
            //option.AddArgument("no-sandbox");
            return option;
        }

        /// <summary>This method checks for headless flag in settings and apply IE options accordingly.</summary>
        /// <returns>ChromeOption.</returns>
        private InternetExplorerOptions CheckHeadlessIE()
        {
            InternetExplorerOptions option = new InternetExplorerOptions();
            //to do
            //if (appsettings.headlessflag)
            //option.addargument("--headless");
            return option;
        }

        /// <summary>
        /// Reset driver to null
        /// </summary>
        public void ResetDriver()
        {
            Driver = null;
        }
    }
}

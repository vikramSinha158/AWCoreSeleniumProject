﻿using AssetWorks.UI.Core.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Threading;

namespace AssetWorks.UI.Core.Extensions
{
    /// <summary>
    /// IWebDriverExtensions class has all common operations of driver
    /// </summary>
    public static class IWebDriverExtensions
    {

        /// <summary>This method switches to new window based on Window Number.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="WindowNumber">The window number.</param>
        public static void SwitchToNewWBrowserTab(this IWebDriver Driver, int WindowNumber)
        {
            var Counter = 0;
            foreach (var Handle in Driver.WindowHandles)
            {
                if (Counter == WindowNumber)
                {
                    AppSettings.CoreLogger.Info($"Switching to browser tab number '{WindowNumber}'");
                    Driver.SwitchTo().Window(Handle);
                    break;
                }
                Counter++;
            }
        }

        /// <summary>This method switches to new window and get title.</summary>
        /// <param name="Driver">Selenium driver instance</param>
        /// <param name="WindowNumber">The window number.</param>
        /// <returns>Title of the new window</returns>
        public static string SwitchToNewWindowAndGetTitle(this IWebDriver Driver, int WindowNumber)
        {
            AppSettings.CoreLogger.Info($"Switching to browser tab number '{WindowNumber}'");
            Driver.SwitchToNewWBrowserTab(WindowNumber);
            var value = Driver.Title;
            AppSettings.CoreLogger.Info($"Getting browser tab title as '{value}'");
            return value;
        }

        /// <summary>This method gets number of iframes in a page.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <returns>Count of iframes as integer.</returns>
        public static int NoOfFrameInPage(this IWebDriver Driver)
        {
            IList<IWebElement> element = Driver.FindElements(By.TagName("iframe"));
            var value = element.Count;
            AppSettings.CoreLogger.Info($"Getting number of frames in page as '{value}'");
            return value;
        }

        /// <summary>This method returns open window's count.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <returns>integer count of open windows</returns>
        public static int GetWindowCount(this IWebDriver Driver)
        {
            var value = Driver.WindowHandles.Count;
            AppSettings.CoreLogger.Info($"Getting number of windows as '{value}'");
            return value;
        }

        /// <summary>This method is used for Click on OK Button of JS Alert.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        public static void AcceptAlert(this IWebDriver Driver)
        {
            try
            {
                IAlert alert = Driver.SwitchTo().Alert();

                if (alert != null)
                {
                    AppSettings.CoreLogger.Info($"Accepting alert");
                    alert.Accept();
                }
            }
            catch { }
        }

        /// <summary>This method clicks on Cancel Button Of JS Alert.</summary>
        /// <param name="Driver">Selenium driver instance.</param>

        public static void CancelAlert(this IWebDriver Driver)
        {
            try
            {
                IAlert alert = Driver.SwitchTo().Alert();

                if (alert != null)
                {
                    AppSettings.CoreLogger.Info($"Dismiss alert");
                    alert.Dismiss();
                }
            }
            catch { }
        }

        /// <summary>This method returns text Of JS Alert.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <returns>Returns JS Alert text as String</returns>

        public static string GetAlertText(this IWebDriver Driver)
        {
            IAlert alert = Driver.SwitchTo().Alert();
            var value = alert.Text;
            AppSettings.CoreLogger.Info($"Getting alert text as '{value}'");
            return value;
        }

        /// <summary>This method enters Value in JS Alert.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Value">Value to be entered in alert.</param>
        public static void EnterValueInAlert(this IWebDriver Driver, string Value)
        {
            IAlert alert = Driver.SwitchTo().Alert();
            alert.SendKeys(Value);
            AppSettings.CoreLogger.Info($"Entering value in alert as '{Value}'");
        }

        /// <summary>This method clicks on Element using JS.</summary>
        /// <param name="Driver">Selenium driver instanc.e</param>
        /// <param name="Element">WebElement to be clicked.</param>
        public static void ClickOnElement(this IWebDriver Driver, IWebElement Element, string elementName)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            AppSettings.CoreLogger.Info($"Clicking on element '{elementName}' using javascript");
            executor.ExecuteScript("arguments[0].click();", Element);
        }

        /// <summary>This method waits for all the anngular request to load</summary>
        /// <param name="Driver">Selenium driver instance</param>
        public static void WaitForAngularRequestsToFinish(this IWebDriver Driver)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Driver;
            js.ExecuteScript("var injector = window.angular.element('body').injector(); var $http = injector.get('$http'); return ($http.pendingRequests.length === 0);");
        }

        /// <summary>This method Scrolls Up the page.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        public static void PageScrollUp(this IWebDriver Driver)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Driver;
            AppSettings.CoreLogger.Info($"Scrolling up page to Top");
            js.ExecuteScript("window.scrollTo(0, 0)");
        }

        /// <summary>This method Scrolls Down the page.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        public static void PageScrollDown(this IWebDriver Driver)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Driver;
            AppSettings.CoreLogger.Info($"Scrolling down page to Bottom");
            js.ExecuteScript("window.scrollTo(0, document.body.scrollHeight)");
        }

        /// <summary>This method drags and drops the element on defined offset..</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Source">Source location.</param>
        /// <param name="OffsetX">X offset of destination.</param>
        /// <param name="OffsetY">Y offset of destination.</param>
        public static void DragDropToOffset(this IWebDriver Driver, IWebElement Source, int OffsetX, int OffsetY, string elementName)
        {
            Actions action = new Actions(Driver);
            AppSettings.CoreLogger.Info($"Dragging element '{elementName}' to (x,y) = ({OffsetX},{OffsetY})");
            action.DragAndDropToOffset(Source, OffsetX, OffsetY).Build().Perform();
        }


        /// <summary>This method highlights the control by scrolling it in view.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Element">The element which should be brought to view .</param>
        public static void ScrollInView(this IWebDriver Driver, IWebElement Element)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Driver;
            AppSettings.CoreLogger.Info($"Scrolling element into view");
            js.ExecuteScript("arguments[0].scrollIntoView(true);", Element);
        }

        /// <summary>This method Mouse hovers to Element.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Element">WebElement on which hover operation is to be performed.</param>
        public static void MouseHover(this IWebDriver Driver, IWebElement Element, string elementName)
        {
            Actions action = new Actions(Driver);
            AppSettings.CoreLogger.Info($"Mouse hovering on element '{elementName}'");
            action.MoveToElement(Element).Build().Perform();
        }

        /// <summary>This method clicks element using action class.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Element">WebElement on which click operation is to be performed.</param>
        public static void ClickElementUsingAction(this IWebDriver Driver, IWebElement Element, string elementName)
        {
            Actions action = new Actions(Driver);
            AppSettings.CoreLogger.Info($"Clicking on element '{elementName}' using action");
            action.MoveToElement(Element).Click().Build().Perform();
        }


        /// <summary>This method Waits until element Visible with timeout.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Time">This is the maximum time user want selenium driver to wait for the element and afterwhich timeout will occur.</param>
        /// <param name="Locator">The locator by witch this element is to be identified.</param>
        public static void WaitForVisibility(this IWebDriver Driver, By Locator, string elementName, int Time = 30)
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(Time));
            AppSettings.CoreLogger.Info($"Waiting for element '{elementName}' to display");
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(Locator));
        }

        /// <summary>This method waits till element is Clickable.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Time">This is the maximum time user want selenium driver to wait for the element and after which timeout will occur.</param>
        /// <param name="Element">The element which is to be clickable..</param>
        public static void WaitForClickable(this IWebDriver Driver, IWebElement Element, string elementName, int Time = 30)
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(Time));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(Element));
        }

        /// <summary>This method waits till Text Present In Element.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Time">This is the maximum time user want selenium driver to wait for the element and afterwhich timeout will occur.</param>
        /// <param name="Element">The element.</param>
        /// <param name="Text">Text to wait for.</param>
        public static void WaitForTextPresentInElement(this IWebDriver Driver, IWebElement Element, string Text, int Time = 30)
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(Time));
            AppSettings.CoreLogger.Info($"Waiting for element to display text '{Text}'");
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElement(Element, Text));
        }

        /// <summary>This method waits for invisibility of element.</summary>
        /// <param name="Driver">Selenium driver instance.</param>
        /// <param name="Time">This is the maximum time user want selenium driver to wait for the element and afterwhich timeout will occur.</param>
        /// <param name="Locator">The locator by witch this element is to be identified.</param>
        public static void WaitForInvisibility(this IWebDriver Driver, By Locator, string elementName, int Time = 30)
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(Time));
            AppSettings.CoreLogger.Info($"Waiting for element '{elementName}' to invisible");
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(Locator));
        }

        /// <summary>
        /// Move Horizontal
        /// </summary>
        public static void ScrollHorizontal(this IWebDriver Driver)
        {
            AppSettings.CoreLogger.Info($"Scrolling horizontal to right most");
            ((IJavaScriptExecutor)Driver).ExecuteScript("window.scrollBy(3000,0)", "");
        }

        /// <summary>
        /// Hightlight the control
        /// </summary>
        /// <param name="Driver"></param>
        /// <param name="Element"></param>
        public static void HighLightControl(this IWebDriver Driver, IWebElement Element, string elementName)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Driver;
            AppSettings.CoreLogger.Info($"Highlighting element '{elementName}'");
            js.ExecuteScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid white;');", Element);
        }

        /// <summary>
        /// Swith To Frame
        /// </summary>
        public static void SwitchToFrame(this IWebDriver Driver, IWebElement IframeElement, string IFrameName)
        {
            AppSettings.CoreLogger.Info($"Switching to iFrame '{IFrameName}'");
            Driver.SwitchTo().Frame(IframeElement);
        }

        /// <summary>
        /// Swicth To New Window
        /// </summary>
        /// <param name="Driver"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static string SwitchToNewWindow(this IWebDriver Driver)
        {
            string parentWin = String.Empty;
            try
            {
                parentWin = Driver.CurrentWindowHandle;
                IList<String> handles = Driver.WindowHandles;
                if (handles.Count > 1)
                {
                    foreach (string handle in handles)
                    {
                        if (handle != parentWin)
                            Driver.SwitchTo().Window(handle);
                    }
                }
                else
                    throw new Exception("New window/tab not found to switch.");
            }
            catch (Exception e)
            {
                AppSettings.CoreLogger.Info(e.Message);
                AppSettings.CoreLogger.Info(e.StackTrace);
                throw new Exception("Unable to find new window/tab, exception : " + e.Message);
            }
            AppSettings.CoreLogger.Info($"Switching to window '{parentWin}'");
            return parentWin;
        }

        /// <summary>
        /// Double Click Using Action
        /// </summary>
        /// <param name="Driver"></param>
        /// <param name="WebElement"></param>
        /// <exception cref="Exception"></exception>
        public static void DoubleClick(this IWebDriver Driver, IWebElement WebElement, string elementName)
        {
            if (WebElement.VerifyElementDisplay(elementName))
            {
                Actions actions = new Actions(Driver);
                AppSettings.CoreLogger.Info($"Double clicking on element '{elementName}'");
                actions.DoubleClick(WebElement).Perform();
            }
            else
                throw new Exception("Element doesn't displayed");
        }

        /// <summary>
        /// ScrollI nto View And Click
        /// </summary>
        /// <param name="Driver"></param>
        /// <param name="Element"></param>
        public static void ScrollIntoViewAndClick(this IWebDriver Driver, IWebElement Element, string elementName)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Driver;
            AppSettings.CoreLogger.Info($"Clicking on element '{elementName}' using javascript");
            js.ExecuteScript("arguments[0].scrollIntoView()", Element);
            js.ExecuteScript("arguments[0].click();", Element);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Value Selection Using ControlKey
        /// </summary>
        /// <param name="Driver"></param>
        public static void ValueSelectionUsingControlKey(this IWebDriver Driver, IList<IWebElement> AssetValues)
        {
            Actions action = new Actions(Driver);

            foreach (IWebElement element in AssetValues)
            {
                action.KeyDown(Keys.Control).Click(element);
            }

            AppSettings.CoreLogger.Info($"Selecting multiple values using control key");
            action.KeyUp(Keys.Control).Build().Perform();
        }

        //Waiting for page to be ready to perform action
        public static void WaitForReady(this IWebDriver Driver, int timeOut = 30)
        {
            bool isAjaxFinished;
            int waitTime = 2000;
            timeOut = timeOut * 1000;

            do
            {
                Thread.Sleep(waitTime);
                isAjaxFinished = (bool)((IJavaScriptExecutor)Driver)
                    .ExecuteScript("return jQuery.active == 0");

                timeOut -= waitTime;
            } while (!isAjaxFinished && timeOut > 0);
        }

        /// <summary>
        /// Scrolling to table elements into view and clicking on row based on given row number
        /// </summary>
        /// <param name="Driver"></param>
        /// <param name="Element"></param>
        /// <param name="RowNumber"></param>
        public static void TableScrollIntoViewAndClick(this IWebDriver Driver, IList<IWebElement> Element, int RowNumber, bool IsClick = false)
        {
            int count = Element.Count;
            AppSettings.CoreLogger.Info($"Scrolling and clicking on table on row number {RowNumber}");
            for (int i = 0; i <= count; i++)
            {
                if (i + 1 == RowNumber)
                {
                    IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)Driver;
                    javaScriptExecutor.ExecuteScript("arguments[0].scrollIntoView()", Element[i]);
                    if (IsClick)
                    {
                        javaScriptExecutor.ExecuteScript("arguments[0].click();", Element[i]);
                        Driver.WaitForReady();
                    }

                    break;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Driver"></param>
        /// <param name="TimeOut">Wait time in Seconds</param>
        public static void WaitForSomeTime(this IWebDriver Driver, int TimeOut = 5)
        {
            TimeOut = TimeOut * 1000;
            Thread.Sleep(TimeOut);
        }

        /// <summary>
        /// Double Click using JavaScript
        /// </summary>
        /// <param name="Driver"></param>
        /// <param name="Element"></param>
        /// <param name="elementName"></param>
        public static void DoubleClickWithJS(this IWebDriver Driver, IWebElement Element, string elementName)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            AppSettings.CoreLogger.Info($"Double Clicking on element '{elementName}' using javascript");
            executor.ExecuteScript("arguments[0].dispatchEvent(new MouseEvent('dblclick', { bubbles: true }));", Element);
        }
    }
}
